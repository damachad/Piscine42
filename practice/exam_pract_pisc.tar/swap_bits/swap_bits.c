/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   swap_bits.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: damachad <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/03/29 11:05:41 by damachad          #+#    #+#             */
/*   Updated: 2023/03/29 11:06:01 by damachad         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
/*
unsigned char	swap_bits(unsigned char octet)
{

}
*/
int	main(void)
{
	unsigned char	a;

	a = 'b';
	printf("a: %c\n", a);
	printf("&a: %i\n", &a);
//	printf("swap_bits(a): %c\n", swap_bits(a));
//	printf("&swap_bits(a): %i\n", &swap_bits(a));
}
